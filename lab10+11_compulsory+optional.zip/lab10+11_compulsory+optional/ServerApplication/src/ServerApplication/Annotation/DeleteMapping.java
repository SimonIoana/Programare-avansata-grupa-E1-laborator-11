package Annotation;

public @interface DeleteMapping {
    String value();
}
