
public class Player {


    private String name;
    private int id;

    public void add(Player players) {
        players.add(players);
        players.setName(this);

    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void remove(Player players) {
        players.remove(players);
        players.setName(this);

    }
}
