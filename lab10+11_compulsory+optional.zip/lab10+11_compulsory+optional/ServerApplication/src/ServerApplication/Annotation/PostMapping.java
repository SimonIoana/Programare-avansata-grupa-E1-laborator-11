package Annotation;

public @interface PostMapping {
    String value();

    String consumes();
}
