package Annotation;

public @interface GetMapping {
}
