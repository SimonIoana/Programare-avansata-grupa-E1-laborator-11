package Annotation;

public class SpringApplication {
}
