import Annotation.*;
import org.springframework.stereotype.Controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
@Controller
@ResponseBody
@RequestMapping("/players")
public class Game {
    private final List<Player> players = new ArrayList<>();
    public Game()
    {
        players.add(new Player(1, "Maria"));
        players.add(new Player(2, "Gelu"));
        players.add(new Player(3, "Alex"));
        players.add(new Player(4, "Ana"));
    }



    public List<Player> getPlayers()
        {
            return players;
        }

    @GetMapping("/count")
    public int countPlayers() {
        return players.size();
    }
    @GetMapping("/{id}")
    public Player getPlayers(@PathVariable("id") int id) {
        return players.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }
    @PostMapping
    public int createPlayers(@RequestParam String name) {
        int id = 1 + players.size();
        players.add(new Player(id, name));
        return id;
    }

    @PostMapping(value = "/obj", consumes="application/json")
    public Player<String>
    createPlayers(@RequestBody Player players) {
        players.add(players);
        return new Player<>(
                "Player created successfully", HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public Player<String> updatePlayers(
            @PathVariable int id, @RequestParam String name) {
        Player players = findById(id);
        if (players == null) {
            return new Player<>(
                    "Player not found", HttpStatus.NOT_FOUND);
        }
        players.setName(name);
        return new Player<>(
                "Player updated successsfully", HttpStatus.OK);
    }

    @DeleteMapping(value = "/{id}")
    public Player<String> deletePlayers(@PathVariable int id) {
        Player players = findById(id);
        if (players == null) {
            return new Player<>(
                    "Player not found", HttpStatus.GONE);
        }
        players.remove(players);
        return new Player<>("Player removed", HttpStatus.OK);
    }

    private int findById(int id) {
        return id;
    }


    public static void run(Class<Player> playerClass, String[] args) {

    }
}
