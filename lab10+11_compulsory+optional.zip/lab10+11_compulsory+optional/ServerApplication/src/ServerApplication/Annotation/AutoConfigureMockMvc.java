package Annotation;

public @interface AutoConfigureMockMvc {
}
