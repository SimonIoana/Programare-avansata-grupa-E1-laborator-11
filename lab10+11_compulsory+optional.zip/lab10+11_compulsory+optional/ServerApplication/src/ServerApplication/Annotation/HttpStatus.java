package Annotation;

public interface HttpStatus {
    Object CREATED = CREATED;
    Object NOT_FOUND = NOT_FOUND;
    Object OK = OK;
    Object GONE = GONE;
}
