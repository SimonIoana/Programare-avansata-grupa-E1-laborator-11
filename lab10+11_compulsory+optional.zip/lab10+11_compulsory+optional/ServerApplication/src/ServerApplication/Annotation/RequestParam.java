package Annotation;

public @interface RequestParam {
}
