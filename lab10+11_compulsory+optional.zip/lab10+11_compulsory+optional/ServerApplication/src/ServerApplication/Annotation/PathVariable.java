package Annotation;

public @interface PathVariable {
}
