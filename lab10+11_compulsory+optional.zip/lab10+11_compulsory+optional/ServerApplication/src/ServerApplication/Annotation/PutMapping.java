package Annotation;

public @interface PutMapping {
}
