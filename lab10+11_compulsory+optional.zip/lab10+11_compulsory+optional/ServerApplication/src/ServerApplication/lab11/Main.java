import Annotation.EnableAutoConfiguration;
import Annotation.RestController;


@RestController
@EnableAutoConfiguration
public class Main {

    public static void main(String[] args) {
        Game.run(Player.class, args);
    }

}