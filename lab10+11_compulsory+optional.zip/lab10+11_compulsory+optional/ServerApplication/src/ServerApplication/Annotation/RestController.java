package Annotation;

public @interface RestController {
}
