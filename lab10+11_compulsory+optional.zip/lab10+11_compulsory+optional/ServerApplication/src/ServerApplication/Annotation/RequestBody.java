package Annotation;

public @interface RequestBody {
}
