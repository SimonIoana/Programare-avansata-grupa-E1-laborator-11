package Annotation;

public @interface ExceptionHandler {
}
