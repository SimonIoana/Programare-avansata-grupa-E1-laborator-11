package Annotation;

public @interface EnableAutoConfiguration {
}
