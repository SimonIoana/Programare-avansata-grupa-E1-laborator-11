package Annotation;

public @interface SpringBootTest {
}
