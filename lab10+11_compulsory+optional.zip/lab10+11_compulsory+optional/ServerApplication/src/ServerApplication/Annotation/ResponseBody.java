package Annotation;

public @interface ResponseBody {
}
