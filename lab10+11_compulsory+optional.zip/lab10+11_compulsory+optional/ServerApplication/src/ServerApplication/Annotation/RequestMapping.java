package Annotation;

public @interface RequestMapping {
}
