import Annotation.ExceptionHandler;
import Annotation.HttpStatus;

import java.time.LocalDateTime;

public class MyExceptionAdvice {
    @ExceptionHandler(value = MyException.class)
    public Player<MyErrorResponse>
    handleGenericNotFoundException(MyException e) {
        MyErrorResponse error = new MyErrorResponse(e.getMessage());
        error.setTime(LocalDateTime.now());
        return new Player<>(error, HttpStatus.NOT_FOUND);
    }
}
